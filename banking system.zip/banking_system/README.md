A full-stack banking system web app built with Go and React.

*Features*

- Create account, Deposit, and withdraw
- View accounts
- Can be easily integrated with database

*Technologies Used*

- Go (Gin)
- React


*License*

MIT License


Your're free to use and share this app's code with anyone. 

Your feedback is important.

diamondkudzai70@gmail.com
